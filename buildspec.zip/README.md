# AWS-Elastic-Beanstalk
Deploying node app using aws elastic bean stalk
